# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource will deploy and configure a content source in a specified search
service application.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the content source is created.
