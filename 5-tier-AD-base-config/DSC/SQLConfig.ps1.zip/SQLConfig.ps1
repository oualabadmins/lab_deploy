﻿<#
    .SQLConfig
    This configuration configures SQL Server with a firewall rule to permit traffic on port 1433, and to add logins 
    and add them to the sysadmin role. It also executes the BaseConfig script.

    kvice 7/11/2018
    5/8/2019  - Added OU "Machines" to mitigate error joining domain to default OU, changed DNS forwarder to 10.50.10.50
    5/23/2019 - Added BaseConfig script (removed again 6/5/2019)
    6/5/2019  - Renamed DSC resource to omit duplicates, added registry resource to set login mode to Mixed, and script
                resource to restart MSSQLSERVER service
#>

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

Configuration SQLConfig
{
    param
    (
        [Parameter(Mandatory = $true)]
        [String]$domainName,

        [Parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential]
        $admincreds
    )

    # Import DSC modules
    Import-DSCResource -ModuleName SQLServerDSC, xNetworking

    # Global variables
    $domainFirstName = ($domainName.Split('.'))[0]
    $sqlserverFQDN = ("SQL." + $domainName)
    $sqlInstanceName = ($sqlserverFQDN + "\MSSQLSERVER")
    $domainAdmin = ($domainFirstName + '\' + $admincreds.UserName)
    
    Node $AllNodes.NodeName
    {
        # Open port 1433
        xFireWall SQLFirewallRule
        {
            Name = "AllowSQLConnection"
            DisplayName = 'Allow SQL Connection'
            Group = 'DSC Configuration Rules'
            Ensure = 'Present'
            Enabled = 'True'
            Profile = ('Domain')
            Direction = 'InBound'
            LocalPort = ('1433')
            Protocol = 'TCP'
            Description = 'Firewall Rule to allow SQL communication'
        }

        # Set login mode to mixed in the registry
        Registry SetMixedMode
        {
            Ensure               = 'Present'
            Key                  = 'HKEY_LOCAL_MACHINE\Software\Microsoft\MSSQLServer\MSSQLServer'
            ValueName            = 'LoginMode'
            ValueData            = '2'
        }

        # Restart the SQL service
        Script RestartSQL
        {
            GetScript = {
                $id = Get-WmiObject -Class Win32_Service -Filter "Name LIKE 'MSSQLSERVER'" | Select-Object -ExpandProperty ProcessId
                $process = (Get-Process -Id $id).Id
                return @{ Result = {$process.ToString()}}
                }

            TestScript = {
                $state = [scriptblock]::Create($GetScript).Invoke()
                $id = Get-WmiObject -Class Win32_Service -Filter "Name LIKE 'MSSQLSERVER'" | Select-Object -ExpandProperty ProcessId
                $process = (Get-Process -Id $id).Id
                if( $state['Result'] -eq $process ) {
                        Write-Verbose "The MSSQLSERVER process has not been restarted."
                        return $false
                        }
                    else {
                        Write-Verbose "The MSSQLSERVER process has already been restarted."            
                        Return $true
                        }
                }

            SetScript = {
                Restart-Service -Name "MSSQLSERVER" -Force
            }
        }

        # Create SQL login for domain admin account
        SqlServerLogin CreateLogin1
        {
            Ensure               = 'Present'
            Name                 = $domainAdmin
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
            DependsOn            = '[Script]RestartSQL'
        }
        
        # Create SQL login sqlsvc
        SqlServerLogin CreateLogin2
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\sqlsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
            DependsOn            = '[Script]RestartSQL'
        }
        
        # Create SQL login spfarmsvc
        SqlServerLogin CreateLogin3
        {
            Ensure               = 'Present'
            Name                 = "$domainFirstName\spfarmsvc"
            LoginType            = 'WindowsUser'
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
            DependsOn            = '[Script]RestartSQL'
        }
        
        # Add logins to sysadmin role
        SqlServerRole Add_ServerRole_AdminSqlforBI
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            MembersToInclude     = $domainAdmin, "$domainFirstName\sqlsvc", "$domainFirstName\spfarmsvc"
            ServerName           = $sqlserverFQDN
            InstanceName         = 'MSSQLSERVER'
            PsDscRunAsCredential = $admincreds
            DependsOn            = '[SqlServerLogin]CreateLogin3'
        }
    }
}