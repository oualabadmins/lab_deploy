﻿<#
    .AppConfig
    This configuration:
    * Provisions IIS, .NET 4.5 and management tools.
    * Creates C:\Files, adds example.txt and shares directory with RWX perms for <domain>\User1.
    * Executes the BaseConfig script.

    kvice 7/13/2018

    7/17/2018 - Updated modules to import
    5/23/2019 - Added BaseConfig script
    6/5/2019  - Removed BaseConfig script, added Script InstallAADConnect to install Azure AD Connect on APP1 ONLY
#>

$configData= @{
    AllNodes = @(
        @{
            NodeName = "localhost"
            PsDscAllowPlainTextPassword = $true
            PsDscAllowDomainUser = $true
        }
    )
}

configuration AppConfig
{
    param
   (
        [Parameter(Mandatory)]
        [String]$DomainName
    )

    # Import DSC modules
    Import-DscResource -Module PSDesiredStateConfiguration, xSmbShare, cNtfsAccessControl
    
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }     

    # Install IIS role 
    WindowsFeature IIS 
    { 
        Ensure  = “Present” 
        Name    = “Web-Server” 
    } 
 
    # Install ASP .NET 4.5 role 
    WindowsFeature AspNet45 
    { 
        Ensure  = “Present” 
        Name    = “Web-Asp-Net45” 
    }
    
    # Install IIS management tools       
    WindowsFeature IISManagementTools {
 
        Name = 'Web-Mgmt-Tools'
        Ensure = 'Present'
        DependsOn = '[WindowsFeature]IIS'
    }

    # Create folder
    File NewFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Files'
            Ensure = "Present"
        }

    # Create file
    File AddFile {
            DestinationPath = 'C:\Files\example.txt'
            Ensure = "Present"
            Contents = ''
        }

    # Share folder
    xSmbShare ShareFolder {
            Ensure = 'Present'
            Name   = 'Files'
            Path = 'C:\Files'
            FullAccess = 'Everyone'
            DependsOn = '[File]NewFolder'
        }

    # Set NTFS perms
    cNtfsPermissionEntry 'FilePermissionChange' {
            Ensure = 'Present'
            DependsOn = "[File]NewFolder"
            Principal = "$DomainName\User1"
            Path = 'C:\Files'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
        }

        Script InstallAADConnect
        {
            SetScript = {
                # Only install on APP1, not subsequent app servers
                if ($env:COMPUTERNAME -match '1$') {
                
                $AADConnectDLUrl="https://download.microsoft.com/download/B/0/0/B00291D0-5A83-4DE7-86F5-980BC00DE05A/AzureADConnect.msi"
                $exe="$env:SystemRoot\system32\msiexec.exe"

                $tempfile = [System.IO.Path]::GetTempFileName()
                $folder = [System.IO.Path]::GetDirectoryName($tempfile)

                $webclient = New-Object System.Net.WebClient
                $webclient.DownloadFile($AADConnectDLUrl, $tempfile)

                Rename-Item -Path $tempfile -NewName "AzureADConnect.msi"
                $MSIPath = $folder + "\AzureADConnect.msi"

                Invoke-Expression "& `"$exe`" /i $MSIPath /qn /passive /forcerestart"
                }
            }

            GetScript =  { @{} }
            TestScript = { 
                return Test-Path "$env:TEMP\AzureADConnect.msi" 
            }
            DependsOn  = '[cNtfsPermissionEntry]FilePermissionChange'
        }
    }
}