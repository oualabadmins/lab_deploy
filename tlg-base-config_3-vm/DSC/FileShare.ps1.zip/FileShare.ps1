﻿<#  FileShare
    Kelley Vice 7/13/2018

    Creates C:\Files, adds example.txt and shares directory with RWX perms for <domain>\User1.

#>

Configuration FileShare {
param
   (
        [Parameter(Mandatory)]
        [String]$DomainName
    )

Import-DscResource -Module PSDesiredStateConfiguration

    Node localhost {

        File NewFolder {
            Type = 'Directory'
            DestinationPath = 'C:\Files'
            Ensure = "Present"
        }
    

        File AddFile {
            DestinationPath = 'C:\Files\example.txt'
            Ensure = "Present"
            Contents = ''
        }

        xSMBShare ShareFolder {
            Ensure = 'Present'
            Name   = Files
            Path = 'C:\Files'
            FullAccess = 'Everyone'
            DependsOn = '[File]Directory'
        }

        cNtfsPermissionEntry 'Files' {
            Ensure = 'Present'
            DependsOn = "[File]NewFolder"
            Principal = "$DomainName\User1"
            Path = 'C:\Files'
            AccessControlInformation = @(
                cNtfsAccessControlInformation
                {
                    AccessControlType = 'Allow'
                    FileSystemRights = 'FullControl'
                    Inheritance = 'ThisFolderSubfoldersAndFiles'
                    NoPropagateInherit = $false
                }
            )
        }
    }
}