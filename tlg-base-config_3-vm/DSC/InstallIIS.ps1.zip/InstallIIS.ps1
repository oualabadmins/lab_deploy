﻿<#
    .InstallIIS
    This configuration provisions IIS, .NET 4.5 and management tools.

    kvice 7/11/2018
#>

configuration InstallIIS
{
    Import-DscResource -Module PSDesiredStateConfiguration
    
# Apply configuration
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }     

    # Install IIS role 
    WindowsFeature IIS 
    { 
        Ensure          = “Present” 
        Name            = “Web-Server” 
    } 
 
    # Install ASP .NET 4.5 role 
    WindowsFeature AspNet45 
    { 
        Ensure          = “Present” 
        Name            = “Web-Asp-Net45” 
    }
    
    # Install IIS management tools       
    WindowsFeature IISManagementTools {
 
        Name = 'Web-Mgmt-Tools'
        Ensure = 'Present'
        DependsOn = '[WindowsFeature]IIS'
    }
 
}
}