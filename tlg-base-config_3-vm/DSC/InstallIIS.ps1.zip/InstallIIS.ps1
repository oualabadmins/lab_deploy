﻿<#
    .CreateADPDC
    This configuration creates a new domain with a new forest and a forest functional level of Server 2016

    kvice 7/11/2018
#>

configuration InstallIIS
{
    Import-DscResource -Module xWebAdministration
    
# Apply configuration
    Node localhost
    {
        LocalConfigurationManager
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }     

    # Install the IIS role 
    WindowsFeature IIS 
    { 
        Ensure          = “Present” 
        Name            = “Web-Server” 
    } 
 
    # Install the ASP .NET 4.5 role 
    WindowsFeature AspNet45 
    { 
        Ensure          = “Present” 
        Name            = “Web-Asp-Net45” 
    } 
}
}